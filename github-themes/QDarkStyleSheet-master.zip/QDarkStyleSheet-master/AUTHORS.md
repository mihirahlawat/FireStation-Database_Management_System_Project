# Authors

## Mainteiner(s)

These people were/are mainteiners of this project.

- 2013-2018
    [Colin Duquesnoy](https://github.com/ColinDuquesnoy) -
    <colin.duquesnoy@gmail.com> -
    original author.
- 2018
    [Daniel Pizetta](https://github.com/dpizetta) -
    <daniel.pizetta@usp.br> -
    improvements and bug fixes.

## Contributor(s)

These people contribute to bug fixes, improvements and so on.
Please, insert your information after the last one.

- Year - Name - `<contact>` - contribution.
- 2018 - [mowoolli](https://github.com/mowoolli) - bug fixes.
- 2018 - Xingyun Wu - `xingyun.wu@foxmail.com` - bug fixes.
- 2018 - [KcHNST](https://github.com/KcHNST) - bug fixes.

Thank you all!
