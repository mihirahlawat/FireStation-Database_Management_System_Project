#!/bin/sh
# Compile example.ui for PyQt.
pyuic5 --from-imports example.ui >  example_pyqt5_ui.py
